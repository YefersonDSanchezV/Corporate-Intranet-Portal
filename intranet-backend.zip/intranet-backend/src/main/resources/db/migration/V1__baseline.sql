-- V1__baseline.psql

-- Baseline inicial de la base de datos existente