package co.com.icvc.intranet_backend.security;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app.security.ldap")
public class LdapSecurityProperties {

    private List<String> userDnPatterns = new ArrayList<>();
    private String userSearchBase;
    /** Active Directory usa sAMAccountName como identificador de inicio de sesión. */
    private String userSearchFilter = "(sAMAccountName={0})";

    public List<String> getUserDnPatterns() {
        return userDnPatterns;
    }

    public void setUserDnPatterns(List<String> userDnPatterns) {
        this.userDnPatterns = userDnPatterns;
    }

    public String getUserSearchBase() {
        return userSearchBase;
    }

    public void setUserSearchBase(String userSearchBase) {
        this.userSearchBase = userSearchBase;
    }

    public String getUserSearchFilter() {
        return userSearchFilter;
    }

    public void setUserSearchFilter(String userSearchFilter) {
        this.userSearchFilter = userSearchFilter;
    }
}
