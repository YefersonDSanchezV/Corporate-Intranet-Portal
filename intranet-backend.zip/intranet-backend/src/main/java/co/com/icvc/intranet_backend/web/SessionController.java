package co.com.icvc.intranet_backend.web;

import java.security.Principal;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Expone la identidad ya autenticada por Kerberos al portal web. */
@RestController
@RequestMapping("/api/session")
public class SessionController {

    @GetMapping("/me")
    SessionUser currentUser(Principal principal, Authentication authentication) {
        return new SessionUser(
            principal.getName(),
            authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority).toList()
        );
    }

    record SessionUser(String username, java.util.List<String> authorities) {
    }
}
