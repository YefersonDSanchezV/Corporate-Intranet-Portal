package co.com.icvc.intranet_backend.security;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.ldap.core.support.AbstractContextSource;
import org.springframework.ldap.core.support.BaseLdapPathContextSource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.kerberos.authentication.KerberosServiceAuthenticationProvider;
import org.springframework.security.kerberos.authentication.sun.SunJaasKerberosTicketValidator;
import org.springframework.security.kerberos.web.authentication.SpnegoAuthenticationProcessingFilter;
import org.springframework.security.ldap.search.FilterBasedLdapUserSearch;
import org.springframework.security.ldap.search.LdapUserSearch;
import org.springframework.security.ldap.userdetails.LdapUserDetailsService;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import jakarta.servlet.http.HttpServletResponse;

@Configuration
@EnableConfigurationProperties(LdapSecurityProperties.class)
public class LdapSecurityConfig {

    @Bean
    SecurityFilterChain securityFilterChain(
        HttpSecurity http,
        SpnegoAuthenticationProcessingFilter spnegoAuthenticationProcessingFilter,
        AuthenticationEntryPoint spnegoEntryPoint,
        KerberosServiceAuthenticationProvider kerberosServiceAuthenticationProvider
    ) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .httpBasic(httpBasic -> httpBasic.disable())
            .formLogin(formLogin -> formLogin.disable())
            .exceptionHandling(exception -> exception.authenticationEntryPoint(spnegoEntryPoint))
            .authenticationProvider(kerberosServiceAuthenticationProvider)
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/actuator/health", "/actuator/info").permitAll()
                .anyRequest().authenticated()
            )
            .addFilterBefore(spnegoAuthenticationProcessingFilter, BasicAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    AuthenticationEntryPoint spnegoEntryPoint() {
        return (request, response, authException) -> {
            response.setHeader("WWW-Authenticate", "Negotiate");
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
        };
    }

    @Bean
    UserDetailsService kerberosUserDetailsService(
        BaseLdapPathContextSource contextSource,
        LdapSecurityProperties ldapSecurityProperties
    ) {
        if (contextSource instanceof AbstractContextSource abstractContextSource) {
            abstractContextSource.setBaseEnvironmentProperties(Map.of("java.naming.referral", "follow"));
        }
        
        String searchBase = ldapSecurityProperties.getUserSearchBase() == null
            ? ""
            : ldapSecurityProperties.getUserSearchBase();
        
        LdapUserSearch userSearch = new FilterBasedLdapUserSearch(
            searchBase,
            ldapSecurityProperties.getUserSearchFilter(),
            contextSource
        );
        ((FilterBasedLdapUserSearch) userSearch).setSearchSubtree(true);

        LdapUserDetailsService ldapUserDetailsService = new LdapUserDetailsService(userSearch);

        // El ticket SPNEGO identifica al usuario del navegador normalmente como
        // usuario@REALM. Active Directory, en cambio, suele buscarlo por
        // sAMAccountName (solo "usuario"). La cuenta del keytab se usa
        // únicamente para descifrar el ticket; nunca debe utilizarse aquí como
        // identidad del usuario final.
        return principal -> ldapUserDetailsService.loadUserByUsername(toDirectoryUsername(principal));
    }

    private String toDirectoryUsername(String principal) {
        int realmSeparator = principal.indexOf('@');
        String username = realmSeparator >= 0 ? principal.substring(0, realmSeparator) : principal;

        int domainSeparator = username.lastIndexOf('\\');
        return domainSeparator >= 0 ? username.substring(domainSeparator + 1) : username;
    }

    @Bean
    SunJaasKerberosTicketValidator sunJaasKerberosTicketValidator(
        @Value("${KRB_SERVICE_PRINCIPAL}") String servicePrincipal,
        @Value("${KRB_KEYTAB_PATH}") String keytabPath,
        ResourceLoader resourceLoader
    ) {
        Resource keytab = resourceLoader.getResource(keytabPath);

        SunJaasKerberosTicketValidator ticketValidator = new SunJaasKerberosTicketValidator();
        ticketValidator.setServicePrincipal(servicePrincipal);
        ticketValidator.setKeyTabLocation(keytab);
        ticketValidator.setDebug(true);
        ticketValidator.setRefreshKrb5Config(true);
        ticketValidator.setHoldOnToGSSContext(false);
        return ticketValidator;
    }

    @Bean
    KerberosServiceAuthenticationProvider kerberosServiceAuthenticationProvider(
        SunJaasKerberosTicketValidator ticketValidator,
        UserDetailsService kerberosUserDetailsService
    ) {
        KerberosServiceAuthenticationProvider provider = new KerberosServiceAuthenticationProvider();
        provider.setTicketValidator(ticketValidator);
        provider.setUserDetailsService(kerberosUserDetailsService);
        return provider;
    }

    @Bean
    AuthenticationManager authenticationManager(
        KerberosServiceAuthenticationProvider kerberosServiceAuthenticationProvider
    ) {
        return new ProviderManager(kerberosServiceAuthenticationProvider);
    }

    @Bean
    SpnegoAuthenticationProcessingFilter spnegoAuthenticationProcessingFilter(
        AuthenticationManager authenticationManager
    ) {
        SpnegoAuthenticationProcessingFilter filter = new SpnegoAuthenticationProcessingFilter();
        filter.setAuthenticationManager(authenticationManager);
        filter.setFailureHandler(spnegoAuthenticationFailureHandler());
        return filter;
    }

    @Bean
    AuthenticationFailureHandler spnegoAuthenticationFailureHandler() {
        return (request, response, exception) -> {
            response.setHeader("WWW-Authenticate", "Negotiate");
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
        };
    }
}
